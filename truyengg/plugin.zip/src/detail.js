load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var doc = fetch(url).html();
    if (doc) {
        var cover = doc.select(".fx-cover img.fx-cover__img").first().attr("src");
        if (cover.startsWith("//")) {
            cover = "http:" + cover;
        }

        let genres = [];
        doc.select(".fx-genres a.fx-genre").forEach(e => {
            genres.push({
                title: e.text(),
                input: e.attr('href').replace(BASE_URL, ''),
                script: "gen.js"
            });
        });

        const infoBook = [
            "Tác giả: "+doc.select(".fx-meta__label:contains(Tác Giả) + .fx-meta__val").text(),
            "Trạng thái: "+doc.select(".fx-status").text(),
            "Lượt xem: "+doc.select(".fx-stat:nth-of-type(1)").text(),
            "Theo dõi: "+doc.select(".fx-stat:nth-of-type(2)").text(),
            "Bình chọn: "+doc.select(".fx-rating-score").text() + doc.select(".fx-rating-count").text()
        ]

        return Response.success({
            name: doc.select("h1[itemprop=name]").text(),
            cover: cover,
            host: BASE_URL,
            author: doc.select(".fx-meta__label:contains(Tác Giả) + .fx-meta__val").text(),
            description: "Đang cập nhật",
            detail: infoBook.join("<br>"),
            ongoing: doc.select(".fx-status.fx-status--ongoing").length > 0,
            genres: genres
        });
    }

    return null;
}