BASE_URL="https://lxmanga.store"
