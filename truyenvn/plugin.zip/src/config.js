let BASE_URL = "https://truyenvn.sbs";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}