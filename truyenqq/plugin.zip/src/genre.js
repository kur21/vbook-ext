load('bypass.js');
load('config.js');

function execute() {
    let response = fetch(BASE_URL);
    if (response.ok) {
        let doc = response.html();
        let genre = [];
        let seen = {};
        doc.select("a[href*=/the-loai/]").forEach(function (e) {
            let input = e.attr("href").replace(/^https?:\/\/[^\/]+/, '');
            if (!seen[input]) {
                seen[input] = true;
                genre.push({
                    title: e.text().trim(),
                    input: input,
                    script: "gen.js"
                });
            }
        });
        return Response.success(genre);
    }
    return null;
}