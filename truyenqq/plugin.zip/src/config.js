let BASE_URL = 'https://truyenqqko.com';
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    return url.replace(/^(https?:\/\/)(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/i, BASE_URL);
}
