load('bypass.js');
load('config.js');
function execute(url) {
    url = normalizeUrl(url);

    var response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var doc = bypass(url, response.html());
    if(doc) {
        var list = [];
        var el = doc.select(".works-chapter-list a");
        for (var i = el.size() - 1; i >= 0; i--) {
            var e = el.get(i);
            list.push({
                name: e.text(),
                url: e.attr("href"),
                host: BASE_URL,
            });
        }
        return Response.success(list);
    }

    return null;
}