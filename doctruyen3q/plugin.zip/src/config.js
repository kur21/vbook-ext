let BASE_URL = "https://doctruyen3qhub.vip";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}