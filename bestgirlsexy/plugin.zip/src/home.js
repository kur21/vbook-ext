function execute() {
    return Response.success([
        {title: "Latest", input: "https://bestgirlsexy.com", script: "gen.js"},
        {title: "Cosplay", input: "https://bestgirlsexy.com/cosplay", script: "gen.js"},
        {title: "Korean", input: "https://bestgirlsexy.com/korean", script: "gen.js"},
        {title: "Europe", input: "https://bestgirlsexy.com/eu-girls", script: "gen.js"},
        {title: "Japan", input: "https://bestgirlsexy.com/japan", script: "gen.js"},
        {title: "China", input: "https://bestgirlsexy.com/china", script: "gen.js"},
        {title: "AIModel", input: "https://bestgirlsexy.com/aimodel", script: "gen.js"},
    ]);
}