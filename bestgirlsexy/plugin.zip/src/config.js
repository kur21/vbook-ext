let BASE_URL="https://bestgirlsexy.com"
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}