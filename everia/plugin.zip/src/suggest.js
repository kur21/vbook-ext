
load('config.js');

function execute(input) {
    let doc = Html.parse(input);
    let books = [];
    doc.select("li").forEach(e => {
        books.push({
            name: e.select("h3 > a").first().text(),
            link: e.select("h3 > a").first().attr("href"),
            cover: e.select(".post_thumb img").first().attr("src"),
            description: "",
            host: BASE_URL
        })
    });

    return Response.success(books);
}