load('config.js');

function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: "/", script: "search.js"},
        {title: "Japan", input: "/category/japan/", script: "search.js"},
        {title: "Korea", input: "/category/korea/", script: "search.js"},
        {title: "Chinese", input: "/category/chinese/", script: "search.js"},
        {title: "Thailand", input: "/category/thailand/", script: "search.js"},
        {title: "Cosplay", input: "/category/cosplay/", script: "search.js"}
    ]);
}