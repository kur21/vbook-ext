function execute() {
    return Response.success([{
        title: "Tất cả thể loại",
        input: "https://everia.club",
        script: "gen.js"
    }, {
        title: "Gravure",
        input: "https://everia.club/category/gravure",
        script: "gen.js"
    }, {
        title: "Aidol",
        input: "https://everia.club/category/aidol",
        script: "gen.js"
    }, {
        title: "Magazine",
        input: "https://everia.club/category/magazin",
        script: "gen.js"
    }, {
        title: "Korea",
        input: "https://everia.club/category/korea",
        script: "gen.js"
    }, {
        title: "Thailand",
        input: "https://everia.club/category/thailand",
        script: "gen.js"
    }, {
        title: "Chinese",
        input: "https://everia.club/category/chinese",
        script: "gen.js"
    }, {
        title: "Cosplay",
        input: "https://everia.club/category/cosplay",
        script: "gen.js"
    }]);
}