load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let title = doc.select("h2.single-post-title.entry-title").first();
    if (title == null) return Response.error("Title not found");

    let pages = [{url: url, number: "1"}];
    let links = doc.select(".page-links a.post-page-numbers");
    for (let i = 0; i < links.size(); i++) {
        let link = links.get(i);
        let pageUrl = link.attr("href");
        let number = link.text().trim();
        if (pageUrl && number && pages.length < 100) {
            pages.push({url: normalizeUrl(pageUrl), number: number});
        }
    }

    let chapters = [];
    for (let i = 0; i < pages.length; i++) {
        chapters.push({
            name: title.text() + " - Page " + pages[i].number,
            url: pages[i].url,
            type: "chapter",
            lock: false,
            pay: false
        });
    }
    return Response.success(chapters);
}
