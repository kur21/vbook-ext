let BASE_URL = "https://everia.club";
try {
    if (DOMAIN) BASE_URL = DOMAIN;
} catch (error) {
}

function normalizeUrl(url) {
    if (!url) return BASE_URL;
    try {
        let baseHost = BASE_URL.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
        return url.replace(/^(https?:\/\/)[^/]+/, "$1" + baseHost);
    } catch (error) {
        return url;
    }
}