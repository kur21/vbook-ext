load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let title = doc.select("h2.single-post-title.entry-title").first();
    if (title == null) return Response.error("Title not found");
    let firstImage = doc.select(".wp-block-gallery img, .entry-content img").first();
    let tags = [];
    let tagLinks = doc.select(".post-tags a");
    for (let i = 0; i < tagLinks.size(); i++) {
        let tag = tagLinks.get(i);
        tags.push({title: tag.text(), input: tag.attr("href"), script: "search.js"});
    }
    return Response.success({
        name: title.text(),
        cover: firstImage == null ? "" : firstImage.attr("src"),
        author: "Đang cập nhật",
        description: title.text(),
        detail: title.text(),
        host: BASE_URL,
        ongoing: false,
        type: "comic",
        format: "comic",
        tags: tags,
        suggests: [{
            title: "You Might Also Like",
            input: doc.select(".wli_popular_posts-listing").html() || "",
            script: "suggest.js"
        }]
    });
}
