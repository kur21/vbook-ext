load('config.js');

function execute(query, page) {
    query = query || "";
    page = page || "1";
    let url;
    if (query.indexOf("/") === 0 || query.indexOf("http") === 0) {
        let base = query.indexOf("http") === 0 ? normalizeUrl(query) : BASE_URL + query;
        url = base;
    } else {
        url = BASE_URL + "/?s=" + encodeURIComponent(query);
    }
    if (parseInt(page, 10) > 1) {
        let queryIndex = url.indexOf("?");
        let path = queryIndex === -1 ? url : url.substring(0, queryIndex);
        let params = queryIndex === -1 ? "" : url.substring(queryIndex);
        path = path.replace(/\/+$/, "");
        url = path + "/page/" + parseInt(page, 10).toString() + "/" + params;
    }
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let el = doc.select(".rt-grid-item, article.post");
    let data = [];
    for (let i = 0; i < el.size(); i++) {
        let item = el.get(i);
        let links = item.select("a");
        let link = null;
        for (let j = 0; j < links.size(); j++) {
            let candidate = links.get(j);
            if (candidate.text() && candidate.attr("href")) {
                link = candidate;
                break;
            }
        }
        let image = item.select("img").first();
        if (link == null || image == null) continue;
        data.push({
            name: link.text(),
            link: link.attr("href"),
            cover: image.attr("src") || image.attr("data-src"),
            description: "",
            host: BASE_URL
        });
    }
    let hasNext = !doc.select("a[aria-label=Next], .pagination-list a[data-paged]").isEmpty();
    return Response.success(data, hasNext ? (parseInt(page, 10) + 1).toString() : "");
}