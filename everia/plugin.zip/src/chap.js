load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let el = doc.select(".entry-content figure.wp-block-image img");
    if (el.isEmpty()) el = doc.select(".entry-content img");
    let data = [];
    for (let i = 0; i < el.size(); i++) {
        let image = el.get(i);
        let src = image.attr("data-src") || image.attr("src");
        if (src) data.push(src);
    }
    return Response.success(data);
}
