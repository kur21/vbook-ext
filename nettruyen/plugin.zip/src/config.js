let BASE_URL = 'https://nettruyen14s.com';
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}
