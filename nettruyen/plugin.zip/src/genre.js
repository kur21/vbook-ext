function execute() {
    return Response.success([{
        title: "Tất cả thể loại",
        input: "https://www.nettruyenking.com/tim-truyen",
        script: "gen.js"
    }, {
        title: "Action",
        input: "https://www.nettruyenking.com/tim-truyen/action",
        script: "gen.js"
    }, {
        title: "Adult",
        input: "https://www.nettruyenking.com/tim-truyen/truong-thanh",
        script: "gen.js"
    }, {
        title: "Adventure",
        input: "https://www.nettruyenking.com/tim-truyen/adventure",
        script: "gen.js"
    }, {
        title: "Anime",
        input: "https://www.nettruyenking.com/tim-truyen/anime",
        script: "gen.js"
    }, {
        title: "Chuyển Sinh",
        input: "https://www.nettruyenking.com/tim-truyen/chuyen-sinh",
        script: "gen.js"
    }, {
        title: "Comedy",
        input: "https://www.nettruyenking.com/tim-truyen/comedy",
        script: "gen.js"
    }, {
        title: "Comic",
        input: "https://www.nettruyenking.com/tim-truyen/comic",
        script: "gen.js"
    }, {
        title: "Cooking",
        input: "https://www.nettruyenking.com/tim-truyen/cooking",
        script: "gen.js"
    }, {
        title: "Cổ Đại",
        input: "https://www.nettruyenking.com/tim-truyen/co-dai",
        script: "gen.js"
    }, {
        title: "Doujinshi",
        input: "https://www.nettruyenking.com/tim-truyen/doujinshi",
        script: "gen.js"
    }, {
        title: "Drama",
        input: "https://www.nettruyenking.com/tim-truyen/drama",
        script: "gen.js"
    }, {
        title: "Đam Mỹ",
        input: "https://www.nettruyenking.com/tim-truyen/dam-my",
        script: "gen.js"
    }, {
        title: "Ecchi",
        input: "https://www.nettruyenking.com/tim-truyen/ecchi",
        script: "gen.js"
    }, {
        title: "Fantasy",
        input: "https://www.nettruyenking.com/tim-truyen/fantasy",
        script: "gen.js"
    }, {
        title: "Gender Bender",
        input: "https://www.nettruyenking.com/tim-truyen/gender-bender",
        script: "gen.js"
    }, {
        title: "Harem",
        input: "https://www.nettruyenking.com/tim-truyen/harem",
        script: "gen.js"
    }, {
        title: "Historical",
        input: "https://www.nettruyenking.com/tim-truyen/historical",
        script: "gen.js"
    }, {
        title: "Horror",
        input: "https://www.nettruyenking.com/tim-truyen/horror",
        script: "gen.js"
    }, {
        title: "Josei",
        input: "https://www.nettruyenking.com/tim-truyen/josei",
        script: "gen.js"
    }, {
        title: "Live action",
        input: "https://www.nettruyenking.com/tim-truyen/live-action",
        script: "gen.js"
    }, {
        title: "Manga",
        input: "https://www.nettruyenking.com/tim-truyen/manga",
        script: "gen.js"
    }, {
        title: "Manhua",
        input: "https://www.nettruyenking.com/tim-truyen/manhua",
        script: "gen.js"
    }, {
        title: "Manhwa",
        input: "https://www.nettruyenking.com/tim-truyen/manhwa-11400",
        script: "gen.js"
    }, {
        title: "Martial Arts",
        input: "https://www.nettruyenking.com/tim-truyen/martial-arts",
        script: "gen.js"
    }, {
        title: "Mature",
        input: "https://www.nettruyenking.com/tim-truyen/mature",
        script: "gen.js"
    }, {
        title: "Mecha",
        input: "https://www.nettruyenking.com/tim-truyen/mecha-117",
        script: "gen.js"
    }, {
        title: "Mystery",
        input: "https://www.nettruyenking.com/tim-truyen/mystery",
        script: "gen.js"
    }, {
        title: "Ngôn Tình",
        input: "https://www.nettruyenking.com/tim-truyen/ngon-tinh",
        script: "gen.js"
    }, {
        title: "One shot",
        input: "https://www.nettruyenking.com/tim-truyen/one-shot",
        script: "gen.js"
    }, {
        title: "Psychological",
        input: "https://www.nettruyenking.com/tim-truyen/psychological",
        script: "gen.js"
    }, {
        title: "Romance",
        input: "https://www.nettruyenking.com/tim-truyen/romance",
        script: "gen.js"
    }, {
        title: "School Life",
        input: "https://www.nettruyenking.com/tim-truyen/school-life",
        script: "gen.js"
    }, {
        title: "Sci-fi",
        input: "https://www.nettruyenking.com/tim-truyen/sci-fi",
        script: "gen.js"
    }, {
        title: "Seinen",
        input: "https://www.nettruyenking.com/tim-truyen/seinen",
        script: "gen.js"
    }, {
        title: "Shoujo",
        input: "https://www.nettruyenking.com/tim-truyen/shoujo",
        script: "gen.js"
    }, {
        title: "Shoujo Ai",
        input: "https://www.nettruyenking.com/tim-truyen/shoujo-ai-126",
        script: "gen.js"
    }, {
        title: "Shounen",
        input: "https://www.nettruyenking.com/tim-truyen/shounen-127",
        script: "gen.js"
    }, {
        title: "Shounen Ai",
        input: "https://www.nettruyenking.com/tim-truyen/shounen-ai",
        script: "gen.js"
    }, {
        title: "Slice of Life",
        input: "https://www.nettruyenking.com/tim-truyen/slice-of-life",
        script: "gen.js"
    }, {
        title: "Smut",
        input: "https://www.nettruyenking.com/tim-truyen/smut",
        script: "gen.js"
    }, {
        title: "Soft Yaoi",
        input: "https://www.nettruyenking.com/tim-truyen/soft-yaoi",
        script: "gen.js"
    }, {
        title: "Soft Yuri",
        input: "https://www.nettruyenking.com/tim-truyen/soft-yuri",
        script: "gen.js"
    }, {
        title: "Sports",
        input: "https://www.nettruyenking.com/tim-truyen/sports",
        script: "gen.js"
    }, {
        title: "Supernatural",
        input: "https://www.nettruyenking.com/tim-truyen/supernatural",
        script: "gen.js"
    }, {
        title: "Tạp chí truyện tranh",
        input: "https://www.nettruyenking.com/tim-truyen/tap-chi-truyen-tranh",
        script: "gen.js"
    }, {
        title: "Thiếu Nhi",
        input: "https://www.nettruyenking.com/tim-truyen/thieu-nhi",
        script: "gen.js"
    }, {
        title: "Tragedy",
        input: "https://www.nettruyenking.com/tim-truyen/tragedy",
        script: "gen.js"
    }, {
        title: "Trinh Thám",
        input: "https://www.nettruyenking.com/tim-truyen/trinh-tham",
        script: "gen.js"
    }, {
        title: "Truyện scan",
        input: "https://www.nettruyenking.com/tim-truyen/truyen-scan",
        script: "gen.js"
    }, {
        title: "Truyện Màu",
        input: "https://www.nettruyenking.com/tim-truyen/truyen-mau",
        script: "gen.js"
    }, {
        title: "Việt Nam",
        input: "https://www.nettruyenking.com/tim-truyen/viet-nam",
        script: "gen.js"
    }, {
        title: "Webtoon",
        input: "https://www.nettruyenking.com/tim-truyen/webtoon",
        script: "gen.js"
    }, {
        title: "Xuyên Không",
        input: "https://www.nettruyenking.com/tim-truyen/xuyen-khong",
        script: "gen.js"
    }, {
        title: "16+",
        input: "https://www.nettruyenking.com/tim-truyen/16",
        script: "gen.js"
    }]);
}