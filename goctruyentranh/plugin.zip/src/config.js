let BASE_URL = "https://goctruyentranhvui41.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (error) {
}

function normalizeUrl(url) {
    let value = String(url || "");
    if (!/^https?:\/\//i.test(value)) {
        return BASE_URL + (value.charAt(0) === "/" ? value : "/" + value);
    }
    return value.replace(/^(https?:\/\/)([^\/]+)/i, "$1" + BASE_URL.replace(/^https?:\/\//i, ""));
}

function absoluteUrl(url) {
    let value = String(url || "");
    if (/^https?:\/\//i.test(value)) {
        return value;
    }
    return BASE_URL + (value.charAt(0) === "/" ? value : "/" + value);
}
