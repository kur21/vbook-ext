let BASE_URL = "https://goctruyentranhvui16.com"

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

const TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJC4bqhaSBIb-G6oWkgVGnDqm4gVHLGsOG7n25nIiwiY29taWNJZHMiOltdLCJyb2xlSWQiOm51bGwsImdyb3VwSWQiOm51bGwsImFkbWluIjpmYWxzZSwicmFuayI6MSwicGVybWlzc2lvbiI6W10sImlkIjoiMDAwMDM2MjY3NSIsInRlYW0iOmZhbHNlLCJpYXQiOjE3NDI3MzkxNDgsImVtYWlsIjoibnVsbCJ9.4m9Cl5dvipIIiW5EX0w2dxDY97PuMAmUyrWeiSL9M1ne1HeiS6H-iUsZW-k1lSrMkAY3mTuG2_tGXVZHhAwYMQ"