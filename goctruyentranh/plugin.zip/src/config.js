let BASE_URL = "https://goctruyentranhvui9.com"

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

const TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJC4bqhaSBIb-G6oWkgVGnDqm4gVHLGsOG7n25nIiwiY29taWNJZHMiOltdLCJyb2xlSWQiOm51bGwsImdyb3VwSWQiOm51bGwsImFkbWluIjpmYWxzZSwicmFuayI6MSwicGVybWlzc2lvbiI6W10sImlkIjoiMDAwMDM2MjY3NSIsInRlYW0iOmZhbHNlLCJpYXQiOjE3MzY5MDY1NzQsImVtYWlsIjoibnVsbCJ9.7iJC3f2JKv-dQKrNwNHkt8z7yW_eJBHbwy1tJBYr5gD-0xbrd5M9YmCtQkRyqht0_51ArCdi9G_RsBIcpjYVdw"