load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let browser = Engine.newBrowser();
    browser.setUserAgent(UserAgent.android());
    browser.launch(url, 10000);
    browser.callJs(
        "var preTag = document.createElement('pre');" +
        "preTag.id = 'auth_token';" +
        "preTag.textContent = localStorage.getItem('Authorization') || '';" +
        "document.body.prepend(preTag);",
        2000
    );
    let doc = browser.html();
    browser.close();
    if (!doc) {
        return Response.error("Không tải được trang truyện");
    }
    let comicId = getComicId(doc);
    if (!comicId) {
        return Response.error("Không tìm thấy mã truyện");
    }
    let token = doc.select("#auth_token").text() || AUTHORIZATION;
    let response = fetch(BASE_URL + "/api/comic/" + comicId + "/chapter?limit=-1", {
        method: "GET",
        headers: {
            Accept: "application/json, text/javascript, */*; q=0.01",
            Referer: url,
            Authorization: token,
            "user-agent": UserAgent.android()
        }
    });
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let json = response.json();
    let chapters = json && json.result && json.result.chapters;
    if (!chapters || chapters.length === 0) {
        return Response.error("Không tìm thấy danh sách chương");
    }
    let data = [];
    chapters.forEach(function (chapter) {
        if (chapter.type === "DOUBLE") {
            return;
        }
        let number = String(chapter.numberChapter);
        data.push({
            name: "#" + number,
            url: BASE_URL + "/truyen/" + getSlug(url) + "/chuong-" + number,
            host: BASE_URL
        });
    });
    data.reverse();
    return Response.success(data);
}

function getComicId(doc) {
    let scripts = doc.select("script");
    for (let i = 0; i < scripts.size(); i++) {
        let match = scripts.get(i).html().match(/const comic\s*=\s*\{[\s\S]*?id:\s*[`"]([^`"]+)[`"]/);
        if (match) {
            return match[1];
        }
    }
    return "";
}

function getSlug(url) {
    let match = url.match(/\/truyen\/([^\/?#]+)/i);
    return match ? match[1] : "";
}
