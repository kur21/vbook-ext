load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let response = fetch(url, {
        method: "GET",
        headers: {
            Referer: BASE_URL,
            "user-agent": UserAgent.android()
        }
    });
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let doc = response.html();
    let data = [];
    let scripts = doc.select('script[type="application/ld+json"]');
    scripts.forEach(function (script) {
        let text = script.html();
        if (text.indexOf('"ItemList"') < 0) {
            return;
        }
        // The chapter links are embedded JSON-LD, not rendered as DOM anchors.
        let matches = text.match(/"url"\s*:\s*"([^"]+\/chuong-[^"]+)"/g) || [];
        matches.forEach(function (entry) {
            let match = entry.match(/"url"\s*:\s*"([^"]+)"/);
            if (match && match[1]) {
                data.push({
                    name: "#" + (match[1].match(/chuong-([^\/?#]+)/i) || ["", ""])[1],
                    url: normalizeUrl(match[1]),
                    host: BASE_URL
                });
            }
        });
    });
    if (data.length === 0) {
        return Response.error("Không tìm thấy danh sách chương");
    }
    return Response.success(data);
}
