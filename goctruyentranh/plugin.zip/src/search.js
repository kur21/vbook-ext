load('config.js');

function execute(key, page) {
    page = page || "0";
    key = key || "";
    let response = fetch(BASE_URL + "/api/v2/search?p=" + encodeURIComponent(page) + "&searchValue=" + encodeURIComponent(key) + "&orders%5B%5D=updatedAt", {
        method : "GET",
        headers : {
            Referer: BASE_URL + '/danh-sach',
            'user-agent': UserAgent.android(),
        },
    });
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let json = response.json();
    let result = json && json.result;
    let allItem = result && result.data;
    if (!allItem) {
        return Response.error("Không đọc được dữ liệu tìm kiếm");
    }
    let data = [];
    allItem.forEach(function (item) {
        data.push({
            name: item.name,
            link: BASE_URL + "/truyen/" + item.nameEn,
            cover: absoluteUrl(item.photo),
            description: "Chap " + ((item.chapterLatest && item.chapterLatest[0]) || ""),
            host: BASE_URL
        });
    });
    let next = result.next === true ? (parseInt(page, 10) + 1).toString() : "";
    return Response.success(data, next);
}