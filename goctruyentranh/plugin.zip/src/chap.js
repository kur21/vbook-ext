load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let slugMatch = url.match(/\/truyen\/([^\/?#]+)/i);
    let numberMatch = url.match(/chuong-([0-9]+)/i);
    if (!slugMatch || !numberMatch) {
        return Response.error("URL chapter không hợp lệ");
    }
    let browser = Engine.newBrowser();
    browser.setUserAgent(UserAgent.android());
    browser.launch(url, 10000);
    browser.callJs(
        "var preTag = document.createElement('pre');" +
        "preTag.id = 'auth_token';" +
        "preTag.textContent = localStorage.getItem('Authorization') || '';" +
        "document.body.prepend(preTag);",
        2000
    );
    let doc = browser.html();
    browser.close();
    if (!doc) {
        return Response.error("Không tải được chapter");
    }
    let token = doc.select("#auth_token").text() || AUTHORIZATION;
    let comicId = getComicId(doc);
    if (!comicId) {
        return Response.error("Không tìm thấy mã truyện");
    }
    let response = fetch(BASE_URL + "/api/chapter/loadAll", {
            method: "POST",
            headers: {
                Accept: "application/json, text/javascript, */*; q=0.01",
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest",
                Referer: url,
                Authorization: token,
                "user-agent": UserAgent.android()
            },
            body: {
                comicId: comicId,
                chapterNumber: numberMatch[1],
                nameEn: slugMatch[1]
            }
        });
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let json = response.json();
    let images = json && json.result && json.result.data;
    if (!images || images.length === 0) {
        return Response.error("Chapter không có dữ liệu ảnh");
    }
    let data = [];
    images.forEach(function (image) {
        let link = typeof image === "string" ? image : image && (image.url || image.src || image.link);
        if (link) {
            data.push({link: absoluteUrl(link), referer: BASE_URL});
        }
    });
    if (data.length === 0) {
        return Response.error("Chapter không có ảnh hợp lệ");
    }
    return Response.success(data);
}

function getComicId(doc) {
    let scripts = doc.select("script");
    for (let i = 0; i < scripts.size(); i++) {
        let match = scripts.get(i).html().match(/const comic\s*=\s*\{[\s\S]*?id:\s*[`"]([^`"]+)[`"]/);
        if (match) {
            return match[1];
        }
    }
    return "";
}
