load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    let slugMatch = url.match(/\/truyen\/([^\/?#]+)/i);
    if (!slugMatch) {
        return Response.error("URL truyện không hợp lệ");
    }
    let slug = slugMatch[1];
    let response = fetch(BASE_URL + "/api/v2/search?p=0&searchValue=" + encodeURIComponent(slug) + "&orders%5B%5D=updatedAt", {
        method: "GET",
        headers: {
            Referer: BASE_URL + "/danh-sach",
            "user-agent": UserAgent.android()
        }
    });
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let json = response.json();
    let items = json && json.result && json.result.data;
    if (!items || items.length === 0) {
        return Response.error("Không tìm thấy truyện");
    }
    let item = items[0];
    let tags = [];
    (item.category || []).forEach(function (category, index) {
        tags.push({
            title: category,
            input: (item.categoryCode && item.categoryCode[index]) || category,
            script: "source.js"
        });
    });
    let latest = item.chapterLatest && item.chapterLatest[0];
    return Response.success({
        name: item.name,
        url: url,
        cover: absoluteUrl(item.photo),
        author: item.author || "Unknown",
        description: item.description || "",
        detail: "Tên khác: " + (item.otherName || "") +
            "<br>Tác giả: " + (item.author || "Unknown") +
            "<br>Trạng thái: " + (item.statusCode === "END" ? "Hoàn thành" : "Đang cập nhật") +
            (latest ? "<br>Chương mới nhất: " + latest : ""),
        ongoing: item.statusCode !== "END",
        host: BASE_URL,
        type: "comic",
        format: "comic",
        tags: tags,
        genres: tags,
        suggests: [],
        reviews: [],
        comments: []
    });
}
