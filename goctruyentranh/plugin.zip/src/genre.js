load('config.js');

function execute() {
    let response = fetch(BASE_URL + '/danh-sach', {
        method : "GET",
        headers : {
            Referer: BASE_URL,
            'user-agent': UserAgent.android(),
        }
    });
    if(response.ok){
        let doc = response.html();
        let allItem = doc.select('.block-category .item-status')
        let data = [];

        allItem.forEach(function (e) {
            let code = e.select(".cbox").attr("data-code");
            let title = e.select("span").text();
            if (code && title) {
                data.push({title: title, input: code, script: "source.js"});
            }
        });
        return Response.success(data);
    }
    return Response.error("HTTP " + response.status);
}