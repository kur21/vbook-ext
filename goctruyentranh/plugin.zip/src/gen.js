load('config.js');

function execute(url, page) {
    page = page || "0";
    let response = fetch(BASE_URL + "/api/v2/search?p=" + encodeURIComponent(page) + (url || ""), {
        method : "GET",
        headers : {
            Referer: BASE_URL + '/danh-sach',
            'user-agent': UserAgent.android()
        },
    });
    
    if (!response.ok) {
        return Response.error("HTTP " + response.status);
    }
    let json = response.json();
    let result = json && json.result;
    let allItem = result && result.data;
    if (!allItem) {
        return Response.error("Không đọc được dữ liệu danh sách");
    }
    let data = [];
    allItem.forEach(function (item) {
        data.push({
            name: item.name,
            link: BASE_URL + "/truyen/" + item.nameEn,
            cover: absoluteUrl(item.photo),
            description: "Chap " + ((item.chapterLatest && item.chapterLatest[0]) || "") +
                " - " + ((item.chapterLatestDate && item.chapterLatestDate[0]) || ""),
            host: BASE_URL
        });
    });
    let next = result.next === true ? (parseInt(page, 10) + 1).toString() : "";
    return Response.success(data, next);
}