let BASE_URL = "https://cuutruyen.net";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

let TOKEN = "Hzag4D6EXMf87FojL1aD7jRF"
let UID = 23242