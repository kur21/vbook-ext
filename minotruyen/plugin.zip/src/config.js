let BASE_URL = "https://minotruyenv7.xyz";
let API = "https://api.cloudkk-v2.xyz/api";
try {
    if (DOMAIN) {
        BASE_URL = DOMAIN;
    }
} catch (error) {
}

function normalizeUrl(url) {
    url = String(url || "");
    return url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/i, BASE_URL);
}

function absoluteUrl(url) {
    url = String(url || "");
    if (!url) return "";
    if (/^https?:\/\//i.test(url)) return url;
    return BASE_URL + (url.charAt(0) === "/" ? "" : "/") + url;
}

let FULL_URL = BASE_URL + "/" + TYPE;