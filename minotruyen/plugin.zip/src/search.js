load('config.js');
function execute(query, page) {
    query = query || "";
    page = page || "1";
    var browser = Engine.newBrowser();
    browser.launch(FULL_URL + "/books/search?q=" + encodeURIComponent(query) + "&page=" + page, 10000);
    sleep(1000);
    var doc = browser.html();
    browser.close();

    if (!doc) return Response.error("Không thể tải trang tìm kiếm");

    var data = [];
    doc.select(".grid > figure").forEach(function (element) {
        var anchor = element.select("a").first();
        var name = element.select("h3").text();
        if (!anchor || !name) return;
        data.push({
            name: name,
            link: absoluteUrl(anchor.attr("href")),
            description: element.select(".mt-2").text(),
            cover: absoluteUrl(element.select("img").attr("src")),
            host: BASE_URL
        });
    });
    var next = doc.select(".w-10.h-10.text-center.bg-blue-600 + .w-10.h-10.text-center").text();

    return Response.success(data, String(next || ""));
}
