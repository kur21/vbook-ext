load('config.js');

function execute(url, page) {
    url = url || "/";
    page = page || "1";
    var separator = url.indexOf("?") >= 0 ? "&page=" : "?page=";
    var browser = Engine.newBrowser();
    browser.launch(absoluteUrl(url) + separator + page, 10000);
    sleep(1000);
    var doc = browser.html();
    browser.close();
    if (!doc) return Response.error("Không thể tải danh sách truyện");

    var data = [];
    doc.select(".grid > figure").forEach(function (element) {
        var anchor = element.select("a").first();
        var name = element.select("h3").text();
        if (!anchor || !name) return;
        data.push({
            name: name,
            link: absoluteUrl(anchor.attr("href")),
            description: element.select(".mt-2").text(),
            cover: absoluteUrl(element.select("img").attr("src")),
            host: BASE_URL
        });
    });
    var next = doc.select(".w-10.h-10.text-center.bg-blue-600 + .w-10.h-10.text-center").text();
    return Response.success(data, String(next || ""));
}
