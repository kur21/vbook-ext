load('config.js');

function execute() {
    const res = fetch(`${API}/books/tags?take=50&category=${TYPE}&format=book`)
    if(res.ok) {
        const data = res.json().data.tags
        const genres = data.map(item => ({
            title: item.name.toUpperCase(),
            input: `/b/${TYPE}/books/search?includeTags=${item.tagId}`,
            script: 'gen.js'       
        }))

        return Response.success(genres)
    }
}