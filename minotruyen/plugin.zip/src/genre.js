load('config.js');

function execute() {
    var res = fetch(API + "/books/tags?take=50&category=" + TYPE + "&format=book");
    if (!res.ok) return Response.error("HTTP " + res.status);
    var body = res.json();
    var data = body && body.data && body.data.tags;
    if (!data) return Response.error("Dữ liệu thể loại không hợp lệ");
    var genres = data.map(function (item) {
        return {
            title: String(item.name || "").toUpperCase(),
            input: "/b/" + TYPE + "/books/search?includeTags=" + item.tagId,
            script: "gen.js"
        };
    });
    return Response.success(genres);
}