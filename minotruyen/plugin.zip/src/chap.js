load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var browser = Engine.newBrowser();
    browser.launch(url, 1000);
    browser.callJs(`
    const allCanvases = document.querySelectorAll('.w-full.mx-auto.relative canvas');
    allCanvases.forEach((canvas, index)=>{ 
        const dataURL = canvas.toDataURL('image/jpeg', 0.5); 
        const newImage = document.createElement('img'); 
        newImage.src = dataURL; 
        newImage.alt = 'convert from canvas'; 
        newImage.width = canvas.width; 
        newImage.height = canvas.height; 
        canvas.parentNode.replaceChild(newImage, canvas);
    });`, 1000)
    const doc = browser.html();
    browser.close();
    

    if(doc) {
        var data = [];
        const listElm = doc.select('.w-full.mx-auto.relative > div > *')
        listElm.forEach(elm => {
            data.push({
                link: elm.attr('src').includes('https://') ? elm.attr('src') : 'http://h.vn/' ,
                script: 'image.js'
            })
        })
        return Response.success(data);
    }
    return null;
}
