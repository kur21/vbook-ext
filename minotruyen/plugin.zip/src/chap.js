load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    var match = url.match(/\/books\/([0-9]+)\/([0-9]+)/i);
    if (!match) return Response.error("Không xác định được mã chương");

    var response = fetch(API + "/books/" + match[1] + "/chapters/" + match[2]);
    if (!response.ok) return Response.error("HTTP " + response.status);
    var body = response.json();
    var images = body && body.data && body.data.chapter && body.data.chapter.images;
    if (!images) return Response.error("Dữ liệu ảnh chương không hợp lệ");

    var data = images.map(function (image) {
        var servers = image.servers || [];
        var server = servers.length ? servers[0] : null;
        return server && server.imageUrl;
    }).filter(function (imageUrl) {
        return !!imageUrl;
    });
    return Response.success(data);
}
