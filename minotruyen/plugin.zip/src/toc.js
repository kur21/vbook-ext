load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    var match = url.match(/\/books\/([0-9]+)/i);
    if (!match) return Response.error("Không xác định được mã truyện");

    var response = fetch(API + "/books/" + match[1] + "/chapters?order=desc");
    if (!response.ok) return Response.error("HTTP " + response.status);
    var body = response.json();
    var chapters = body && body.data && body.data.chapters;
    if (!chapters) return Response.error("Dữ liệu chương không hợp lệ");

    var base = url.replace(/\/$/, "");
    var list = chapters.map(function (chapter) {
        return {
            name: "Chapter " + chapter.chapterNumber,
            url: base + "/" + chapter.chapterId,
            host: BASE_URL
        };
    }).reverse();
    return Response.success(list);
}
