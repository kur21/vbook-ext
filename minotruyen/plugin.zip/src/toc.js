load('config.js');

function execute(url) {
    let bookId = url.split('/').pop()
    // let response = fetch(`${API}/cbooks/${bookId}/chapters?order=desc`);
    let response = fetch('https://api.cloudkk-v2.xyz/api/books/3/chapters?order=desc');
    if(response.ok) {
        const data = response.json()
        const chapters = data.data.chapters
        const list = chapters.map(book => {
            return {
                name: `Chapter ${book.chapterNumber}`,
                url: `${url}/${book.chapterId}`,
                host: BASE_URL
            }
        }).reverse()

        return Response.success(list);
    }

    return null;
}