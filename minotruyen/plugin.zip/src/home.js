load('config.js');
function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "/b/" + TYPE + "/books/search", script: "gen.js"},
        {title: "Truyện Mới", input: "/b/" + TYPE + "/trending?type=CREATED_AT", script: "gen.js"},
        {title: "Truyện Nổi Bật", input: "/b/" + TYPE + "/trending?type=TOP_VIEW", script: "gen.js"},
        {title: "Top Theo Dõi", input: "/b/" + TYPE + "/trending?type=TOP_FOLLOW", script: "gen.js"}
    ]);
}
