load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    var browser = Engine.newBrowser();
    browser.launch(url, 10000);
    sleep(1000);
    var doc = browser.html();
    browser.close();
    if (!doc) return Response.error("Không thể tải trang truyện");

    var article = doc.select("article.px-3");
    if (article.isEmpty()) return Response.error("Không tìm thấy thông tin truyện");
    var image = article.select("img").first();
    var name = article.select("h1").text();
    var author = article.select("h1 + *").text() || "";
    var tags = article.select(".flex.flex-wrap.gap-1 > a.uppercase").map(function (element) {
        return {
            title: element.text(),
            input: absoluteUrl(element.attr("href")),
            script: "gen.js"
        };
    });
    var related = doc.select('h2[title="TRUYỆN CÙNG THỂ LOẠI"] + div.grid');
    var suggests = related.isEmpty() ? [] : [{
        title: "Truyện cùng thể loại",
        input: related.html(),
        script: "suggests.js"
    }];

    return Response.success({
        name: name,
        author: author,
        cover: image ? absoluteUrl(image.attr("src")) : "",
        description: article.select("p.text-base.whitespace-pre-line").text(),
        detail: "Tên truyện: " + name + (author ? " <br>Tác giả: " + author : ""),
        url: url,
        type: "comic",
        format: "comic",
        ongoing: true,
        tags: tags,
        genres: [],
        suggests: suggests,
        reviews: [],
        comments: [],
        host: BASE_URL
    });
}
