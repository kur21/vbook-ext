load('config.js');

function execute(input) {
    var doc = Html.parse(input || "");
    var data = [];
    doc.select("figure").forEach(function (element) {
        var anchor = element.select("a").first();
        var name = element.select("h3").text();
        if (!anchor || !name) return;
        data.push({
            name: name,
            link: absoluteUrl(anchor.attr("href")),
            description: element.select(".mt-2").text(),
            cover: absoluteUrl(element.select("img").attr("src")),
            host: BASE_URL
        });
    });
    return Response.success(data);
}
