function execute() {
    return Response.success(
        [
            {
                "title": "AI",
                "input": "/hentai/the-loai/ai",
                "script": "gen.js"
            },
            {
                "title": "Anime",
                "input": "/hentai/the-loai/anime",
                "script": "gen.js"
            },
            {
                "title": "3D",
                "input": "/hentai/the-loai/3d",
                "script": "gen.js"
            },
            {
                "title": "Adult",
                "input": "/hentai/the-loai/adult",
                "script": "gen.js"
            },
            {
                "title": "Ahegao",
                "input": "/hentai/the-loai/ahegao",
                "script": "gen.js"
            },
            {
                "title": "Animal girl",
                "input": "/hentai/the-loai/animal-girl",
                "script": "gen.js"
            },
            {
                "title": "Artist",
                "input": "/hentai/the-loai/artist",
                "script": "gen.js"
            },
            {
                "title": "Bạo Dâm",
                "input": "/hentai/the-loai/bao-dam",
                "script": "gen.js"
            },
            {
                "title": "CG",
                "input": "/hentai/the-loai/cg",
                "script": "gen.js"
            },
            {
                "title": "Chơi Hai Lỗ",
                "input": "/hentai/the-loai/choi-hai-lo",
                "script": "gen.js"
            },
            {
                "title": "Cosplay",
                "input": "/hentai/the-loai/cosplay",
                "script": "gen.js"
            },
            {
                "title": "Côn Trùng",
                "input": "/hentai/the-loai/con-trung",
                "script": "gen.js"
            },
            {
                "title": "Doujinshi",
                "input": "/hentai/the-loai/doujinshi",
                "script": "gen.js"
            },
            {
                "title": "Đồ Bơi",
                "input": "/hentai/the-loai/do-boi",
                "script": "gen.js"
            },
            {
                "title": "Elf",
                "input": "/hentai/the-loai/elf",
                "script": "gen.js"
            },
            {
                "title": "Fantasy",
                "input": "/hentai/the-loai/fantasy",
                "script": "gen.js"
            },
            {
                "title": "Furry",
                "input": "/hentai/the-loai/furry",
                "script": "gen.js"
            },
            {
                "title": "Futanari",
                "input": "/hentai/the-loai/futanari",
                "script": "gen.js"
            },
            {
                "title": "Gangbang",
                "input": "/hentai/the-loai/gangbang",
                "script": "gen.js"
            },
            {
                "title": "Gender Bender",
                "input": "/hentai/the-loai/gender-bender",
                "script": "gen.js"
            },
            {
                "title": "Giáo Viên",
                "input": "/hentai/the-loai/giao-vien",
                "script": "gen.js"
            },
            {
                "title": "Group",
                "input": "/hentai/the-loai/group",
                "script": "gen.js"
            },
            {
                "title": "Guro",
                "input": "/hentai/the-loai/guro",
                "script": "gen.js"
            },
            {
                "title": "Hài Hước",
                "input": "/hentai/the-loai/hai-huoc",
                "script": "gen.js"
            },
            {
                "title": "Hãm Hiếp",
                "input": "/hentai/the-loai/ham-hiep",
                "script": "gen.js"
            },
            {
                "title": "Harem",
                "input": "/hentai/the-loai/harem",
                "script": "gen.js"
            },
            {
                "title": "Hầu Gái",
                "input": "/hentai/the-loai/hau-gai",
                "script": "gen.js"
            },
            {
                "title": "Hậu Môn",
                "input": "/hentai/the-loai/hau-mon",
                "script": "gen.js"
            },
            {
                "title": "Housewife",
                "input": "/hentai/the-loai/housewife",
                "script": "gen.js"
            },
            {
                "title": "Kinh Dị",
                "input": "/hentai/the-loai/kinh-di",
                "script": "gen.js"
            },
            {
                "title": "Kogal",
                "input": "/hentai/the-loai/kogal",
                "script": "gen.js"
            },
            {
                "title": "Lãng Mạn",
                "input": "/hentai/the-loai/lang-man",
                "script": "gen.js"
            },
            {
                "title": "Lão Gìa Dâm",
                "input": "/hentai/the-loai/lao-gia-dam",
                "script": "gen.js"
            },
            {
                "title": "Loạn Luân",
                "input": "/hentai/the-loai/loan-luan",
                "script": "gen.js"
            },
            {
                "title": "Loli",
                "input": "/hentai/the-loai/loli",
                "script": "gen.js"
            },
            {
                "title": "Mang Thai",
                "input": "/hentai/the-loai/mang-thai",
                "script": "gen.js"
            },
            {
                "title": "Manhua",
                "input": "/hentai/the-loai/manhua",
                "script": "gen.js"
            },
            {
                "title": "Manhwa",
                "input": "/hentai/the-loai/manhwa",
                "script": "gen.js"
            },
            {
                "title": "Mắt Kính",
                "input": "/hentai/the-loai/mat-kinh",
                "script": "gen.js"
            },
            {
                "title": "Mature",
                "input": "/hentai/the-loai/mature",
                "script": "gen.js"
            },
            {
                "title": "Milf",
                "input": "/hentai/the-loai/milf",
                "script": "gen.js"
            },
            {
                "title": "Mind Break",
                "input": "/hentai/the-loai/mind-break",
                "script": "gen.js"
            },
            {
                "title": "Mind Control",
                "input": "/hentai/the-loai/mind-control",
                "script": "gen.js"
            },
            {
                "title": "Monster Girl",
                "input": "/hentai/the-loai/monster-girl",
                "script": "gen.js"
            },
            {
                "title": "Ngực Lớn",
                "input": "/hentai/the-loai/nguc-lon",
                "script": "gen.js"
            },
            {
                "title": "Ngực Nhỏ",
                "input": "/hentai/the-loai/nguc-nho",
                "script": "gen.js"
            },
            {
                "title": "Nô Lệ",
                "input": "/hentai/the-loai/no-le",
                "script": "gen.js"
            },
            {
                "title": "NTR",
                "input": "/hentai/the-loai/ntr",
                "script": "gen.js"
            },
            {
                "title": "Nữ Sinh",
                "input": "/hentai/the-loai/nu-sinh",
                "script": "gen.js"
            },
            {
                "title": "OneShot",
                "input": "/hentai/the-loai/oneshot",
                "script": "gen.js"
            },
            {
                "title": "Quái Vật",
                "input": "/hentai/the-loai/quai-vat",
                "script": "gen.js"
            },
            {
                "title": "Scat",
                "input": "/hentai/the-loai/scat",
                "script": "gen.js"
            },
            {
                "title": "Series",
                "input": "/hentai/the-loai/series",
                "script": "gen.js"
            },
            {
                "title": "Shota",
                "input": "/hentai/the-loai/shota",
                "script": "gen.js"
            },
            {
                "title": "Supernatural",
                "input": "/hentai/the-loai/supernatural",
                "script": "gen.js"
            },
            {
                "title": "Thể Thao",
                "input": "/hentai/the-loai/the-thao",
                "script": "gen.js"
            },
            {
                "title": "Thú Vật",
                "input": "/hentai/the-loai/thu-vat",
                "script": "gen.js"
            },
            {
                "title": "Trap",
                "input": "/hentai/the-loai/trap",
                "script": "gen.js"
            },
            {
                "title": "Truyện Comic",
                "input": "/hentai/the-loai/truyen-comic",
                "script": "gen.js"
            },
            {
                "title": "Không Che",
                "input": "/hentai/the-loai/truyen-khong-che",
                "script": "gen.js"
            },
            {
                "title": "Truyện Màu",
                "input": "/hentai/the-loai/truyen-mau",
                "script": "gen.js"
            },
            {
                "title": "Truyện Ngắn",
                "input": "/hentai/the-loai/truyen-ngan",
                "script": "gen.js"
            },
            {
                "title": "Virgin",
                "input": "/hentai/the-loai/virgin",
                "script": "gen.js"
            },
            {
                "title": "Xúc Tua",
                "input": "/hentai/the-loai/xuc-tua",
                "script": "gen.js"
            },
            {
                "title": "Y Tá",
                "input": "/hentai/the-loai/y-ta",
                "script": "gen.js"
            },
            {
                "title": "Yaoi",
                "input": "/hentai/the-loai/yaoi",
                "script": "gen.js"
            },
            {
                "title": "Yuri",
                "input": "/hentai/the-loai/yuri",
                "script": "gen.js"
            },
            {
                "title": "Real Life Cosplayers",
                "input": "/hentai/the-loai/real-life-cosplayers",
                "script": "gen.js"
            }
        ]
    )
}