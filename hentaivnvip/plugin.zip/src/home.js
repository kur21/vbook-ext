function execute() {
    return Response.success([
        {title: "Cập Nhật", input: "https://hentaivnvip.net/truyen-hentai-moi", script: "gen.js"},
        {title: "Hot Tuần", input: "https://hentaivnvip.net/truyen-hot", script: "gen.js"},
        {title: "Full Color", input: "https://hentaivnvip.net/the-loai/full-color", script: "gen.js"},
        {title: "Không Che", input: "https://hentaivnvip.net/the-loai/khong-che", script: "gen.js"},
    ]);
}